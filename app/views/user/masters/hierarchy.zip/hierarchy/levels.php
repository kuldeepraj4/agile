<?php
require_once APPROOT.'/views/includes/user/header.php';
?>
<br><br>
            <section class="list-200 content-box" style="margin: auto;max-width: 700px">
            <h1 class="list-200-heading">Hierarchy Levels</h1>


    <section class="list-200-top-action">
        <div class="list-200-top-action-left">

            <!-- input used for sory by call-->
            <input type="hidden" id="sort_by" value="">
            <!-- //input used for sory by call-->
            

            <div class="filter-item">
                <label>Name</label>
            <input type="text" placeholder="Name" data-filter="search" onkeyup="show_list()">
            </div>            
            <div class="filter-item">
            </div> 
        </div>
        <div class="list-200-top-action-right">
            <div>
            <?php
            if(in_array('PADMIN', USER_PRIV)){
                echo "<button class='btn_grey button_href'><a href='../user/masters/hierarchy/levels/add-new'>Add New</a></button>";
            }
            ?>
        </div>
        </div>
                
    </section>

            <div class="table  table-a">
                <table>
                    <thead>
                    <tr>
                        <th>Sr No</th>
                        <th style="text-align:left" data-table-sort-by="name">Name</th>
                        <th style="text-align:left" data-table-sort-by="parent">Parent Level</th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>                       
                    </thead>
                    <tbody id="tabledata"></tbody>
                </table>
            </div>
        </section>

<script type="text/javascript">
function show_list(){
  var sort_by=$('#sort_by').val();
var value=$('[data-filter="search"]').val();
 let param={
  sort_by:sort_by
 }

 get_hierarchy_levels(param).then(function(data) {
  // Run this when your request was successful
  if(data.status){
    console.log(data)
    //Run this if response has list
    if(data.response.list){
$('#tabledata').html("");
var counter=0;
$.each(data.response.list, function(index, item) {
    if(item.name.toLowerCase().includes(value)){
counter++;
    var row=``;
    row+=`<tr>`;
    row+=`<td>`+counter+`</td>`;
    row+=`<td style="text-align:left">`+item.name+`</td>`;
    row+=`<td style="text-align:left">`+item.parent+`</td>`;
    row+=`<td><a style="color:blue" href="../user/masters/hierarchy/levels/assign-users?eid=`+item.eid+`">Assign users</a></td>`;
    
    row+=`<td>`;
<?php if(in_array('P0138', USER_PRIV)){
    ?>
    row+=`<button title="Edit" class="btn_grey_c"><a href="../user/masters/hierarchy/levels/update?eid=`+item.eid+`"><i class="fa fa-pen"></i></a></button>`;
    <?php
} ?>
<?php if(in_array('P0139', USER_PRIV)){
    ?>
    row+=`<button title="Delete" class="btn_grey_c" data-action="delete" data-eid="`+item.eid+`"><i class="fa fa-trash"></i></button>`;
    <?php
} ?>
    row+=`</td>`; 

    row+=`</tr>`;
    $('#tabledata').append(row);
       
}
})   
    }
  }
}).catch(function(err) {
  // Run this when promise was rejected via reject()
}) 
}
show_list()
</script>



<script type="text/javascript">

$(document).ready(function(){
 $(document).on("click", "[data-action='delete']",function(){
    if(confirm('Do you want to roles group ?')){
        var eid=$(this).data("eid");
    $.ajax({
      url:window.location.href+'/delete-action',
      type:'POST',
       data:{
        delete_eid:eid
       },
       context: this,
        success:function(data){
               if((typeof data)=='string'){
               data=JSON.parse(data) 
               }
               
               if(data.status){
                    $(this).parent().parent().fadeOut();
               }else{
                alert(data.message)
               }
      }
    })
    }
  });
});

</script>


<script type="text/javascript">
  function sort_table(){
    show_list()
  }
</script>


<?php
require_once APPROOT.'/views/includes/user/footer.php';
?>