<?php
require_once APPROOT.'/views/includes/user/header.php';
?>
<br><br>
        <section class="form-a" style="max-width: 600px">
            <div class="form-a-header">Add Hierarchy Level</div>
            <form method="POST" id="MyForm" onsubmit="return add_new()">
                <div>
                    <label>Parent Level</label>
                    <select name="parent_id" required="required"></select>
                </div>
                <div>
                  <label>Level Name</label>
                    <input type="text" name="name" pattern="[a-zA-Z ]{3,}" required="required">
                </div>
                <div>
                    <button class="form-submit-btn" id="submit">SAVE</button>
                </div>
            </form>
         </section>
<script type="text/javascript">
    function add_new(){
        submit_to_wait_btn('#submit','loading')
                $('#formErro').show()
    var form = document.getElementById('MyForm');
    var isValidForm = form.checkValidity();
    var currentForm = $('#MyForm')[0];
    var formData=new FormData(currentForm);
    if(isValidForm){
    var arr=$('#MyForm').serializeArray();
    var obj={}
    for(var a=0;a<arr.length;a++ ){
        obj[arr[a].name]=arr[a].value
    }
    $.ajax({
        url:window.location.href+'-action',
        type:'POST',
        data: obj,
        success:function(data){
          alert(data)
          console.log(data)
               if((typeof data)=='string'){
               data=JSON.parse(data) 
               }
               alert(data.message);
               if(data.status){
                location.href='user/masters/hierarchy/levels';
                wait_to_submit_btn('#submit','ADD')
               }else{
                wait_to_submit_btn('#submit','ADD')
               }
        }
    })
}
return false
    }
</script>
<script type="text/javascript">
function show_highrarcy_levels(){
 get_hierarchy_levels().then(function(data) {
  // Run this when your request was successful
  if(data.status){
console.log(data)
    //Run this if response has list
    if(data.response.list){
      var options="";
          options+=`<option value="">- - Select - -</option>`
        $.each(data.response.list, function(index, item) {
            options+=`<option value="`+item.id+`">`+item.name+`</option>`;               
        })
        $('[name="parent_id"]').html(options);     
    }
  }
}).catch(function(err) {
  // Run this when promise was rejected via reject()
}) 
}

show_highrarcy_levels()

</script>



<?php
require_once APPROOT.'/views/includes/user/footer.php';
?>